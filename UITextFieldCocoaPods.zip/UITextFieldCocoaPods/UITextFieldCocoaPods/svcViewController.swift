//
//  svcViewController.swift
//  UITextFieldCocoaPods
//
//  Created by subhanireddy on 31/01/21.
//

import UIKit

class SvcViewController: UIViewController {
    
    var displayLbl:UILabel!
    var backButton:UIButton!
    var scrollView:UIScrollView!
    var vc:UIViewController!
    override func viewDidLoad() {
        
       
        super.viewDidLoad()

       scrollView = UIScrollView(frame: CGRect(x: 0, y: 0, width: 450, height: 10000))

       view.addSubview(scrollView)
        
        backButton = UIButton(type: UIButton.ButtonType.system)
        backButton.frame = CGRect(x: 20, y: 40, width: 70, height: 40)
      //  backButton.backgroundColor = UIColor.systemBlue
        backButton.setImage(UIImage(named: "back"), for: UIControl.State.normal)
        backButton.addTarget(self, action: #selector(onChangeButton), for: UIControl.Event.touchUpInside)
        scrollView.addSubview(backButton)
        // Do any additional setup after loading the view.
    }
    
    @objc func onChangeButton(){
        
        dismiss(animated: true) {
            
          
            print("back")
        }
    }

   

}
