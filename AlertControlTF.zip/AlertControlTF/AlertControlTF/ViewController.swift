//
//  ViewController.swift
//  AlertControlTF
//
//  Created by subhanireddy on 03/02/21.
//

import UIKit



class ViewController: UIViewController,UITextFieldDelegate {

    var firstNameTF=UITextField()

       var secondNameTF=UITextField()

       var ageTF=UITextField()

       var emailTF=UITextField()

       var mobileTF=UITextField()
    
       var dateOfBirthTF = UITextField()

       var showBtn:UIButton!

       var saveBtn:UIButton!

       var details:[String] = []

       var lbl = UILabel()

       var lbl1 = UILabel()

       var lbl2 = UILabel()

       var lbl3 = UILabel()

       var lbl4 = UILabel()

       var lbl5 = UILabel()
     
       var lbl6 = UILabel()
    
       var genderSegment = UISegmentedControl()
    
       var gender = ""
    
       var maritalStatussegment = UISegmentedControl()
    
       var marital = ""
    
       var genderLbl = UILabel()
    
       var maritalLbl = UILabel()
    
       var emailReg:[String] = []

       var firstNameTfCalyr = CALayer()

       var secondNameTfCalyr = CALayer()

       var ageTfCalyr = CALayer()

       var emailCalyr = CALayer()

       var mobileCalyr = CALayer()
    
       var dobCalyr = CALayer()
    
       var datePicker = UIDatePicker()

       var ac = UIAlertController()
    
       var okButton = UIAlertAction()
    
    

       override func viewDidLoad() {

           super.viewDidLoad()
        
           firstNameTF.delegate = self

           secondNameTF.delegate = self

           ageTF.delegate = self

           emailTF.delegate = self

           mobileTF.delegate = self
         
           dateOfBirthTF.delegate = self

           view.backgroundColor = .blue

           createUI()

       // alertButton()
           // Do any additional setup after loading the view.

       }
    
    func createUI(){

        let taps = UITapGestureRecognizer(target: self, action: #selector(tapbtn))

        view.addGestureRecognizer(taps)

    

        // show Button

        showBtn  = UIButton(type: UIButton.ButtonType.system)

        showBtn.frame = CGRect(x: 320, y: 60, width: 60, height: 40)

        showBtn.setTitle("Show", for: UIControl.State.normal)

        showBtn.backgroundColor = .orange

        showBtn.layer.cornerRadius = 15.0

        showBtn.clipsToBounds = true

        showBtn.addTarget(self, action: #selector(savedData(tapped:)), for: UIControl.Event.touchUpInside)

        view.addSubview(showBtn)

        

        // Save Button

        saveBtn  = UIButton(type: UIButton.ButtonType.system)

        saveBtn.frame = CGRect(x: 20, y: 850, width: 300, height: 40)

        saveBtn.setTitle("Save", for: UIControl.State.normal)

        saveBtn.backgroundColor = .green

        saveBtn.isEnabled = false

        saveBtn.addTarget(self, action: #selector(savebtn), for: UIControl.Event.touchUpInside)

        view.addSubview(saveBtn)

     
        //firstName TextField

        firstNameTF.frame = CGRect(x: 20, y: 100, width: 300, height: 40)

        firstNameTF.keyboardType = .asciiCapable
     
        firstNameTF.placeholder = "Firstname"

        firstNameTfCalyr.frame = CGRect(x: 5, y: 40, width: 290, height: 2)

        firstNameTfCalyr.backgroundColor = UIColor.white.cgColor

        firstNameTF.layer.addSublayer(firstNameTfCalyr)

        firstNameTF.backgroundColor = .blue

        firstNameTF.autocorrectionType = .no

        firstNameTF.clearButtonMode = .whileEditing

        firstNameTF.borderStyle = .none

        firstNameTF.keyboardAppearance = .alert

        firstNameTF.autocapitalizationType = .none

        firstNameTF.textColor = .black

        view.addSubview(firstNameTF)

      
        //secondName TextField

        secondNameTF.frame =  CGRect(x: 20, y: 200, width: 300, height: 40)

        secondNameTF.placeholder = "SecondName"

        secondNameTF.textColor = .black

        secondNameTF.backgroundColor = .blue

        secondNameTfCalyr.frame = CGRect(x: 5, y: 40, width: 290, height: 2)

        secondNameTfCalyr.backgroundColor = UIColor.white.cgColor

        secondNameTF.layer.addSublayer(secondNameTfCalyr)

        secondNameTF.autocapitalizationType = .none

        secondNameTF.autocorrectionType = .no

        secondNameTF.keyboardType = .asciiCapable

        secondNameTF.clearButtonMode = .whileEditing

        secondNameTF.borderStyle = .none

        view.addSubview(secondNameTF)
     

        // dateOfBirth TextField
     
     dateOfBirthTF.frame = CGRect(x: 20, y: 300, width: 300, height: 40)

     dateOfBirthTF.placeholder = "DateOfBirth"

     dateOfBirthTF.textColor = .black

     dateOfBirthTF.backgroundColor = .blue

     dobCalyr.frame = CGRect(x: 5, y: 40, width: 290, height: 2)

     dobCalyr.backgroundColor = UIColor.white.cgColor

     dateOfBirthTF.layer.addSublayer(dobCalyr)

     dateOfBirthTF.keyboardType = .numberPad

     dateOfBirthTF.clearButtonMode = .whileEditing
       
     dateOfBirthTF.borderStyle = .none
    

     view.addSubview(dateOfBirthTF)

        datePicker = UIDatePicker(frame: CGRect(x: 120, y: 300, width:250 , height: 40))
        datePicker.isHidden = true
        datePicker.tintColor = .white
        
        datePicker.datePickerMode = .date
        self.datePicker.maximumDate = Date()
    
        datePicker.addTarget(self, action: #selector(dateAction(sender:)), for: UIControl.Event.valueChanged)

                view.addSubview(datePicker)

            
        //age TextField

        ageTF.frame = CGRect(x: 20, y: 400, width: 300, height: 40)

        ageTF.placeholder = "Age"

        ageTF.textColor = .black

        ageTF.backgroundColor = .blue

        ageTfCalyr.frame = CGRect(x: 5, y: 40, width: 290, height: 2)

        ageTfCalyr.backgroundColor = UIColor.white.cgColor

        ageTF.layer.addSublayer(ageTfCalyr)

        ageTF.keyboardType = .numberPad

        ageTF.clearButtonMode = .whileEditing

        ageTF.borderStyle = .none

        view.addSubview(ageTF)
     
     // gender Label
     
     genderLbl = UILabel(frame: CGRect(x: 20, y: 500, width: 100, height: 30))
     genderLbl.text = "Gender"
     view.addSubview(genderLbl)
     
     // gener segments
     
      let gender = ["Male","Female"]
     
     genderSegment = UISegmentedControl(items: gender)
     
     genderSegment.frame = CGRect(x: 150, y: 500, width: 200, height: 40)
        
     genderSegment.addTarget(self, action: #selector(genderSegmentAction), for: UIControl.Event.valueChanged)
     view.addSubview(genderSegment)
     
     //marital Label
     
     maritalLbl = UILabel(frame: CGRect(x: 20, y: 600, width: 150, height: 30))
     maritalLbl.text = "MaritalStatus"
     view.addSubview(maritalLbl)
     
     // marital status
     
     let maritalDetails = ["Single","Married"]
     
     maritalStatussegment = UISegmentedControl(items: maritalDetails)
     
     maritalStatussegment.frame = CGRect(x: 150, y: 600, width: 200, height: 40)
     maritalStatussegment.addTarget(self, action: #selector(maritalStatusSegmentAction), for: UIControl.Event.valueChanged)
     view.addSubview(maritalStatussegment)
     
        //email TextField

        emailTF.frame =  CGRect(x: 20, y: 700, width: 300, height: 40)

        emailTF.placeholder = "ValidEmail"

        emailTF.textColor = .black

        emailTF.backgroundColor = .blue

        emailCalyr.frame = CGRect(x: 5, y: 40, width: 290, height: 2)

        emailCalyr.backgroundColor = UIColor.white.cgColor

        emailTF.layer.addSublayer(emailCalyr)

        emailTF.keyboardType = .emailAddress

        emailTF.clearButtonMode = .whileEditing

        emailTF.borderStyle = .none

        emailTF.autocapitalizationType = .none

        view.addSubview(emailTF)

       

       //mobileNumber TextField

        mobileTF.frame = CGRect(x: 20, y: 800, width: 300, height: 40)

       mobileTF.placeholder = "ValidMobileNumber"

        mobileTF.textColor = .black

        mobileTF.backgroundColor = .blue

        mobileCalyr.frame = CGRect(x: 5, y: 40, width: 290, height: 2)

        mobileCalyr.backgroundColor = UIColor.white.cgColor

        mobileTF.layer.addSublayer(mobileCalyr)

        mobileTF.keyboardType = .numberPad

        mobileTF.borderStyle = .none

        mobileTF.clearButtonMode = .whileEditing

        view.addSubview(mobileTF)

    
    }
    

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {

      

          print("textFieldShouldBeginEditing")

       var returnValue:Bool = false

           if(textField == firstNameTF){

               lbl1.frame = CGRect(x: 20, y: 60, width: 200, height: 40)

               lbl1.textColor = .systemPink

                lbl1.text  = "FirstName"

               view.addSubview(lbl1)

             

               returnValue = true

           }

            if(textField == secondNameTF) {


               lbl2.frame = CGRect(x: 20, y: 160, width: 200, height: 40)

               lbl2.textColor = .systemPink

               lbl2.text = "SecondName"

               view.addSubview(lbl2)

               if (firstNameTF.text!.count > 3){

                   returnValue = true

               }else{
                
                ac = UIAlertController(title: "Alert", message: "Please enter your FirstName", preferredStyle: UIAlertController.Style.alert)
               var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                    
                    
                })
                
                ac.addAction(okAction)
                present(ac, animated: true, completion: nil
                )


                   returnValue = false

               }

           }
        
        if (textField == dateOfBirthTF){
            
            lbl3.frame = CGRect(x: 20, y: 260, width: 200, height: 40)

            lbl3.textColor = .systemPink

            lbl3.text = "DateOfBirth"

            view.addSubview(lbl3)
        

            if(firstNameTF.text!.count > 0) &&             (secondNameTF.text!.count > 0)

                        {

                
                            returnValue = true

                        }else

                        {
                            ac = UIAlertController(title: "Alert", message: "Please enter your SecondName", preferredStyle: UIAlertController.Style.alert)
                           var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                                
                                
                            })
                            
                            ac.addAction(okAction)
                            present(ac, animated: true, completion: nil
                            )

                            
                            returnValue = false

                        }

                    }
        

            if (textField == ageTF){

                
               lbl4.frame = CGRect(x: 20, y: 360, width: 200, height: 40)

               lbl4.textColor = .systemPink

               lbl4.text = "Age"

               view.addSubview(lbl4)

                if (firstNameTF.text!.count > 3 && secondNameTF.text!.count > 3 && dateOfBirthTF.text!.count > 0){

                   returnValue = true

               }else{
                
                ac = UIAlertController(title: "Alert", message: "Please Enter DateOfBirth", preferredStyle: UIAlertController.Style.alert)
               var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                    
                    
                })
                
                ac.addAction(okAction)
                present(ac, animated: true, completion: nil
                )
                   returnValue = false

               }

           }

            if (textField == emailTF){

               

               lbl5.frame = CGRect(x: 20, y: 660, width: 200, height: 40)

                       lbl5.textColor = .systemPink

                       lbl5.text  = "Email"

                      view.addSubview(lbl5)

            
                if (firstNameTF.text!.count > 3 && secondNameTF.text!.count > 3 && Int(ageTF.text!)! >= 18 && Int(ageTF.text!)! <= 100 && (genderSegment.selectedSegmentIndex == 0 || genderSegment.selectedSegmentIndex == 1) && (maritalStatussegment.selectedSegmentIndex == 0 || maritalStatussegment.selectedSegmentIndex == 1))
                
                {

                   returnValue = true

               }else
                
                
                
               {
                
                ac = UIAlertController(title: "Alert", message: "Please Enter Your Age Between 18 - 100", preferredStyle: UIAlertController.Style.alert)
               var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                    
                    
                })
                
                ac.addAction(okAction)
                present(ac, animated: true, completion: nil
                )

                   returnValue = false

               }

           }

        if (textField == mobileTF){

               lbl6.frame = CGRect(x: 20, y: 760, width: 200, height: 40)

               lbl6.textColor = .systemPink

               lbl6.text  = "MobileNumber"

               view.addSubview(lbl6)

            
           if (firstNameTF.text!.count > 3 && secondNameTF.text!.count > 3 && Int(ageTF.text!.count) > 0 && emailTF.text!.count > 7){


                   returnValue  = true

               }else {
                
                
                ac = UIAlertController(title: "Alert", message: "Please Enter Your Valid Email", preferredStyle: UIAlertController.Style.alert)
               var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                    
                    
                })
                
                ac.addAction(okAction)
                present(ac, animated: true, completion: nil
                )


                   returnValue = false

               }


       }

            return returnValue

       }

       
       func textFieldDidBeginEditing(_ textField: UITextField) {

          // print("textFieldDidBeginEditing")

          // return true
       

       }

       func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {

           let returnValue1 = true;

            if(textField == emailTF){

               

               return isValidEmail(textField.text!)

           }else

           if (textField == mobileTF){

    
               return isValidPhone(textField.text!)

           }
          // print("textFieldShouldEndEditing")
        if textField == ageTF{
            
            datePicker.isHidden = true
        }
       return returnValue1

       }

       func isValidEmail(_ email: String) -> Bool {

           let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{3,64}"

           let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)

           return emailPred.evaluate(with: email)

       }

       func isValidPhone(_ phone: String) -> Bool {

           let phoneNumberRegex = "^[6-9][0-9]{9}$";

           let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneNumberRegex)

           let result  = phoneTest.evaluate(with: phone)

           return result

       }

       func textFieldDidEndEditing(_ textField: UITextField) {

          // print("textFieldDidEndEditing")

          // textField.backgroundColor = .white

        if(firstNameTF.text!.count != 0) && (secondNameTF.text!.count != 0) && Int(ageTF.text!.count) > 0 && (emailTF.text!.count) > 7 && (mobileTF.text!.count == 10) && (genderSegment.selectedSegmentIndex == 0 || genderSegment.selectedSegmentIndex == 1) && (maritalStatussegment.selectedSegmentIndex == 0 || maritalStatussegment.selectedSegmentIndex == 1)
        
        
           {

                      saveBtn.isEnabled = true
         
           }
           
        
        if textField == secondNameTF{
            datePicker.isHidden = false
        }else
        {
            datePicker.isHidden = true
        }
       }

       func textFieldDidChangeSelection(_ textField: UITextField) {

         //  print("textFieldDidChangeSelection")

          // return true

       
       }

       func textFieldShouldReturn(_ textField: UITextField) -> Bool {

         //  print("textFieldShouldReturn")

           self.switchBasedNextTextField(textField)

           return  true

       }

       func switchBasedNextTextField(_ textField: UITextField) {

           switch textField {

           case self.firstNameTF:

               self.secondNameTF.becomeFirstResponder()

           case self.secondNameTF:

               self.ageTF.becomeFirstResponder()

           case self.ageTF:

               self.emailTF.becomeFirstResponder()

           case self.emailTF:

                 self.mobileTF.becomeFirstResponder()



           default:

               self.firstNameTF.resignFirstResponder()

           }

       }

       func textFieldShouldClear(_ textField: UITextField) -> Bool {

         //  print("textFieldShouldClear")

           return true

       }


      @objc  func ageDisplay(){


                

            }
    
       func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {

         //  print("textField")

           if(string==""){

               print("backspace detected")

               return true

           }

    
           if(textField == firstNameTF ||  textField ==  secondNameTF){
            
             

               let firstNameAndSecondNameAllowableCharacters = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ")

               if (string.rangeOfCharacter(from: firstNameAndSecondNameAllowableCharacters) != nil){

                   return true

               }else{
                
                ac = UIAlertController(title: "Alert", message: "Please enter only characters", preferredStyle: UIAlertController.Style.alert)
               var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                    
                    
                })
                
                ac.addAction(okAction)
                present(ac, animated: true, completion: nil
                )

                   return false

               }
           }

           if (textField == ageTF){

               let ageAllowableRange = CharacterSet(charactersIn: "0123456789")

               if(string.rangeOfCharacter(from: ageAllowableRange) != nil){

                   return true

               }else{
                
                ac = UIAlertController(title: "Alert", message: "Please enter only numbers", preferredStyle: UIAlertController.Style.alert)
               var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                    
                    
                })
                
                ac.addAction(okAction)
                present(ac, animated: true, completion: nil
                )


                   return false

               }

           }

           if (textField == emailTF){

               
               let emailAllowableCharacters = CharacterSet(charactersIn: "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-.@")

               if (string.rangeOfCharacter(from: emailAllowableCharacters) != nil){

                   return true

               }else{
                
                ac = UIAlertController(title: "Alert", message: "Please enter valid Email", preferredStyle: UIAlertController.Style.alert)
               var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                    
                    
                })
                
                ac.addAction(okAction)
                present(ac, animated: true, completion: nil
                )


                   return false

               }

           }

           if (textField == mobileTF){


                if mobileTF.text == ""{
                    
                    if  string == "6" || string == "7" || string == "8" || string == "9"{
                        return true
                    }else
                    {
                        
                        
                        ac = UIAlertController(title: "Alert", message: "Please Enter valid MobileNumber", preferredStyle: UIAlertController.Style.alert)
                       var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
                            
                            
                        })
                        
                        ac.addAction(okAction)
                        present(ac, animated: true, completion: nil
                        )

                        return false
                    }
                }
                    else
                    {
                                
                let currentCharacterCount = textField.text?.count ?? 0

                if currentCharacterCount <= 9

                    {

            
                      //   savedBtn.isEnabled = true

                                            return true

                                        }

                                        else

                                        {

                                            return false

                                        }

                                    }

                }
        return true
       }
    
    @objc func dateAction(sender:UIDatePicker)

        {

             let components = Calendar.current.dateComponents([.year, .month, .day], from: sender.date)

                if let day = components.day, let month = components.month, let year = components.year {

                    print("\(day) \(month) \(year)")

                    let formater = DateFormatter()
                    dateOfBirthTF.text = formater.string(for:datePicker.date)

                    dateOfBirthTF.text = ("\(day)/\(month)/\(year)")

                    
                    let presentDate = Date()

                    let birthday: Date = datePicker.date

                    let dobObj = Calendar.current
                
                let ageComponents = dobObj.dateComponents([.year], from: birthday, to: presentDate)

                    let age = ageComponents.year!

                    ageTF.text = "\(age)"

                }

            }



    @objc func savebtn(){

         lbl.frame = CGRect(x: 50, y: 950, width: 250, height: 30)

         lbl.text = "succesfully update your data"

         lbl.textAlignment = .center

         lbl.clipsToBounds = true

         lbl.layer.cornerRadius = 18

         lbl.backgroundColor = .systemPink

         view.addSubview(lbl)

        if let fn = firstNameTF.text,fn.isEmpty == false{

            details.append(" Firstname:\(fn)")

         }

        if let sn = secondNameTF.text,sn.isEmpty == false {

             details.append("Secondname:\(sn)")

         }
        if let dob = dateOfBirthTF.text,dob.isEmpty == false{
            
            details.append("DateOfBirth:\(dob)")
        }
     if gender.isEmpty == false{
         details.append("Gender:\(gender)")
     }
     
     if marital.isEmpty == false{
         details.append( "MaritalStatus:\(marital)")
     }

        if let ag = ageTF.text,ag.isEmpty == false{

             details.append("Age:\(ag)")

         }

        if let em = emailTF.text,em.isEmpty == false{

             details.append("Email:\(em)")

         }

        if let mb = mobileTF.text,mb.isEmpty == false{

             details.append("Mobile:\(mb)")

         }

     firstNameTF.text  = nil

     secondNameTF.text = nil
        
     dateOfBirthTF.text = nil
        
     ageTF.text = nil

     emailTF.text = nil

     mobileTF.text = nil
    
     genderSegment.selectedSegmentIndex = -1
    
     maritalStatussegment.selectedSegmentIndex = -1

        saveBtn.isEnabled = false
        gender = ""
        marital = ""
       
        saveAlert()
         print(details)

     }
       @objc func tapbtn(){

           view.endEditing(true)

       }

      @objc  func genderSegmentAction(){
        
        if genderSegment.selectedSegmentIndex == 0{
            
            gender = "Male"
            
        if genderSegment.selectedSegmentIndex == 1{
            gender = "Female"
            }
        }
    }

    @objc func maritalStatusSegmentAction(){
        
        if maritalStatussegment.selectedSegmentIndex == 0{
            marital = "Single"
            
        if maritalStatussegment.selectedSegmentIndex == 1{
            marital = "Married"
            }
        }
    }
      
     func saveAlert(){
        
        ac = UIAlertController(title: "Alert", message: " Succesfully Saved Your Details", preferredStyle: UIAlertController.Style.actionSheet)
       var okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (Alert) in
            
            
        })
        
        ac.addAction(okAction)
        present(ac, animated: true, completion: nil
        )

    }

       @objc func savedData(tapped:UIButton){
        

           if details == []{

    
           }else

           {

           let svc = storyboard?.instantiateViewController(identifier: "svc") as! SvcViewController

    
           svc.modalPresentationStyle = .fullScreen

           present(svc,animated: true){

               svc.vc = self

               var a = 0

               let b = 8

               for i in 0..<self.details.count{

            
                   svc.displayLbl = UILabel(frame: CGRect(x: 20, y: 100+i*30+a, width:350, height: 40))

                

                   svc.displayLbl.text = "\(self.details[i])"

            
                   if i%b == 7{


                       a += 50

                   }

                 //  svc.detailsLbl.backgroundColor = .systemYellow

                 //  print("\(self.details[i])")

                   svc.view.addSubview(svc.displayLbl)

         
               }

              svc.scrollView.contentSize  = CGSize(width: svc.displayLbl.frame.maxX, height: svc.displayLbl.frame.maxY)

               

           }

           }

       }


}




