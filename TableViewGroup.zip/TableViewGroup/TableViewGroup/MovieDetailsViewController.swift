//
//  MovieDetailsViewController.swift
//  TableViewGroup
//
//  Created by subhanireddy on 13/02/21.
//

import UIKit

class MovieDetailsViewController: UIViewController {

    var movieView:ViewController!
    var details:MovieDetails!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }


}
