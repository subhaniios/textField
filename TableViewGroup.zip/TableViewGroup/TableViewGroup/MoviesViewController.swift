//
//  MoviesViewController.swift
//  TableViewGroup
//
//  Created by subhanireddy on 13/02/21.
//

import UIKit
import AVKit
import AVFoundation

class MoviesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
   
    
   
    var detailsTV:UITableView!
    var movies:MovieDetails!
    var AVPVC:AVPlayerViewController!
    var trailerBtn:UIButton!
    var songBtn:UIButton!
    var dataTask:URLSessionDataTask!
    var movieSongsArray:[String] = []
    var songsLbl : UILabel!
    override func viewDidLoad() {
        createUI()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func createUI(){
        
        detailsTV  = UITableView(frame: view.frame, style: UITableView.Style.plain)
       
        detailsTV.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        detailsTV.delegate = self
        detailsTV.dataSource = self
        view.addSubview(detailsTV)
        DispatchQueue.main.async {
            self.detailsTV.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 7
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = detailsTV.dequeueReusableCell(withIdentifier: "cell")
        
        if (indexPath.row  == 0){
            
          var  dataTaskObj = URLSession.shared.dataTask(with: URL(string: "https://services.brninfotech.com/tws/\(movies!.posters![0])".replacingOccurrences(of: " ", with: "%20"))!, completionHandler: { (data, res, err) in
               
                DispatchQueue.main.async {
                    
                    cell?.imageView!.image = UIImage(data: data!)
                    
                   
                }
            })
            dataTaskObj.resume()
        
        
        }else if (indexPath.row == 1){
            
            cell?.textLabel?.text = "Director:-\(movies!.director!)"
        }else if (indexPath.row == 2){
            
            if movies.industry != nil {
            cell?.textLabel?.text =  "Industry:-\(movies!.industry!)"
            }else{
                cell?.textLabel?.text =  "Industry Not Avilable"
            }
        }else if indexPath.row == 3{
            
            cell?.textLabel?.text  = " Actors:-\(movies!.actors!)".replacingOccurrences(of: "[", with: "").replacingOccurrences(of: "]", with: "").replacingOccurrences(of: "\"", with: "").replacingOccurrences(of: ",", with: "\n")

            cell?.textLabel?.numberOfLines = 0
                    }
        else if (indexPath.row == 4){
            
            if movies!.story != nil{
                cell?.textLabel?.text = " Story:-\(movies!.story!)"
            }else{
                cell?.textLabel!.text =  "Story Not Avilable"
            }

            cell?.textLabel?.numberOfLines = 0
        }else if (indexPath.row == 5){
        
                let songsArr = movies!.songs!
               // print(songsArr)
                movieSongsArray.removeAll()
                if (movies!.songs != [])
                {
                    for b in 0..<songsArr.count
                    {
                        let temp1 = songsArr[b]
                        let temp2 = temp1.split(separator: "/")
                        let temp3 = temp2[3]
                        let temp4 = temp3.replacingOccurrences(of: ".mp3", with: "")
                        print(temp4)
                        songsLbl = UILabel()
                        songsLbl.frame = CGRect(x: 50, y: 10+(50*b), width: 350, height: 40)
                        songsLbl.text = "\(temp4)"
                        cell?.addSubview(songsLbl)
                       // cell?.textLabel?.numberOfLines = 0

                        songBtn = UIButton(type: UIButton.ButtonType.custom)
                        songBtn.frame = CGRect(x: 4, y: 10+(50*b), width: 45, height: 40)
                     //  songsBtn.setImage(UIImage(named: "playing"), for: UIControl.State.normal)
                         
                        songBtn.addTarget(self, action: #selector(audioPlayerAction), for: UIControl.Event.touchUpInside)
                        movieSongsArray.append(temp1.replacingOccurrences(of: " ", with: "%20"))
                        cell!.addSubview(songBtn)
                        songBtn.tag = b
                        let temp = "https://services.brninfotech.com/tws/" +  (movies?.posters![0].replacingOccurrences(of: " ", with: "%20"))!
                        let imageURL = URL(string: temp)

                        let data = try? Data(contentsOf: imageURL!)
                        songBtn.setImage(UIImage(data: data!), for: UIControl.State.normal)
                    }
                }else
                {
                    
                    cell?.textLabel!.text = "No Songs Available "
                  //  cell.addSubview(songsLabel)
                   

                }
                
            
            
        }else if (indexPath.row == 6){
            
            var trailerArray:[String] = []
          //  trailerArray.removeAll()
            trailerArray = movies!.trailers!
            for i in 0..<trailerArray.count{
                let temp1 = trailerArray[i]
                let temp2 = temp1.split(separator: "/")
                let temp3 = temp2[2]
                let temp4 = temp3
                print(temp4)
                cell?.textLabel?.text =  "\(temp4)"
                cell?.textLabel?.textAlignment = .center
                let btn = UIButton(frame: CGRect(x: 10, y: 10, width: 40, height: 20))
        
                let temp = "https://services.brninfotech.com/tws/" +  movies!.posters![0].replacingOccurrences(of: " ", with: "%20")
                let imageURL = URL(string: temp)

                let data = try? Data(contentsOf: imageURL!)
                btn.setImage(UIImage(data: data!), for: UIControl.State.normal)
                btn.addTarget(self, action: #selector(videoPlayFunction(sender:)), for: UIControl.Event.touchUpInside)
                cell!.addSubview(btn)

            }
        }
            
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        print("button taped")
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        if ( indexPath.row == 0){
            return 150
        }else if (indexPath.row == 5){
        
            return 300
        }
        return UITableView.automaticDimension
        }
    
// audioPlayer action
    @objc func audioPlayerAction(sender:UIButton){

        let tag = sender.tag
        let urlPath = URL(string: "https://services.brninfotech.com/tws/\(movieSongsArray[tag].replacingOccurrences(of: " ", with: "%20"))")
        print("Taped on song button")
        
        AVPVC = AVPlayerViewController()
        AVPVC.player = AVPlayer(url: urlPath!)
        present(AVPVC, animated: true) {
            self.AVPVC.player?.play()
        }
    }
    
    // trailerAction
    @objc func videoPlayFunction(sender:UIButton)
    {
        let tag = sender.tag
        let urlPath = URL(string: "https://services.brninfotech.com/tws/\(movies!.trailers![tag].replacingOccurrences(of: " ", with: "%20"))")

        AVPVC = AVPlayerViewController()
        AVPVC.player = AVPlayer(url: urlPath!)

        present(AVPVC, animated: true)
        {

            self.AVPVC.player?.play()
        }
    }



}
