//
//  ViewController.swift
//  TableViewGroup
//
//  Created by subhanireddy on 13/02/21.
//

import UIKit


class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    var convertedData=[MovieDetails]()
    var tollyDetails = [MovieDetails]()
    var bollyDetails = [MovieDetails]()
    var otherDetails = [MovieDetails]()
    var tittleTableView:UITableView!
    var urlReq:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        createUI()
        
    }
    
    
    //creating a function for UI
    func createUI(){
        
        tittleTableView = UITableView(frame: view.frame, style: UITableView.Style.grouped)
        tittleTableView.register(UITableViewCell.self, forCellReuseIdentifier: "abc")
        tittleTableView.delegate = self
        tittleTableView.dataSource = self
        view.addSubview(tittleTableView)
        
        urlReq = URLRequest(url: URL(string: "https://services.brninfotech.com/tws/MovieDetails2.php?mediaType=movies")!)
        urlReq.httpMethod = "POST"
        
        dataTaskObj = URLSession.shared.dataTask(with: urlReq, completionHandler: { (data, res, err) in
            
            DispatchQueue.main.sync {
                
                var decoderObj = JSONDecoder()
                do{
                    self.convertedData = try decoderObj.decode([MovieDetails].self, from: data!)
                    print(self.convertedData.count)

                    var a = 0
                    for i in 0..<self.convertedData.count{
                        
                        if self.convertedData[i].industry == "Tollywood"{
                        
                            self.tollyDetails.append(self.convertedData[i])
                           // print("tollywood \(self.tollyDetails.count)")
                            
                        }else if self.convertedData[i].industry == "Bollywood"{
                            self.bollyDetails.append(self.convertedData[i])
                          //  print("bollywood \(self.bollyDetails.count)")
                    }else {
                        self.otherDetails.append(self.convertedData[i])
                     //   print("others \(self.otherDetails.count)")
                        
                    }
                       
                    }
                    
                    self.tittleTableView.reloadData()
                    
            }catch{
                print("something went wrong")
            }
            }
            })
        dataTaskObj.resume()
        
        }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if (section == 0){
            return "Tollywood"
        }else if (section == 1){
            return "Bollywood"
        }else{
            return "otherwood"
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        
        if (section == 0){
        return tollyDetails.count
        }else if (section == 1){
            return bollyDetails.count
        }else{
            return otherDetails.count
        }
    
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = tittleTableView.dequeueReusableCell(withIdentifier: "abc", for: indexPath)
        
       
        if (indexPath.section == 0){
            
        cell.textLabel!.text =  "\(tollyDetails[indexPath.row].title!)"
          
        }else if (indexPath.section == 1){
            
            cell.textLabel!.text = "\(bollyDetails[indexPath.row].title!)"
        }else {
            
            cell.textLabel!.text = "\(otherDetails[indexPath.row].title!)"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = storyboard?.instantiateViewController(identifier: "mvc") as! MoviesViewController
        if (indexPath.section == 0){
        vc.movies = tollyDetails[indexPath.row]
            vc.title = tollyDetails[indexPath.row].title!
        }else if (indexPath.section == 1){
            vc.title = tollyDetails[indexPath.row].title!
            vc.movies = bollyDetails[indexPath.row]
        }else if (indexPath.section == 2){
            vc.title = tollyDetails[indexPath.row].title!
            vc.movies = otherDetails[indexPath.row]
        }

        navigationController?.pushViewController(vc, animated: true)
    }
   
    
    }

