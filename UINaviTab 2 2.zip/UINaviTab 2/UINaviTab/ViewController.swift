//
//  ViewController.swift
//  UINaviTab
//
//  Created by subhanireddy on 06/02/21.
//

import UIKit
 var convertedData:[MovieDetails]?
class ViewController: UIViewController {
   
    
   // var convertedData:[MovieDetails]!
    var URLReq:URLRequest!
    var dataTaskObj:URLSessionDataTask!
    var tollywoodscrollView:UIScrollView!
    var movieViewTapGR:UITapGestureRecognizer!
    var tollywoodImages:UIButton!
    var detaials : MovieDetails!
    var trailerArray:[String] = []
    var commonUrl = "https://services.brninfotech.com/tws/"
    var posters = ""
    var tollywoodPostersArray:[String] = []
    var tollywoodIndustry:String = ""
    var tittle:String = ""
    var titleLbl:UILabel!
    var posterArray:[String] = []
    var postersTableView:UITableView!
    override func viewDidLoad() {
        
       
        
        //scrollView for tollywood posters
        tollywoodscrollView = UIScrollView(frame: CGRect(x: 20, y: 20, width: 415, height: 900))
      //  navigationController?.delegate = self
        view.addSubview(tollywoodscrollView)
        
        // calling function
        movieDetails()
        super.viewDidLoad()
       
       
        // Do any additional setup after loading the view.
    }

// taking function for passing data in to view
    
    
    
    
    func movieDetails(){
    
        // url request
            URLReq = URLRequest(url: URL(string: "https://services.brninfotech.com/tws/MovieDetails2.php?mediaType=movies")!)
            // url passing into POST method
        
            URLReq.httpMethod = "POST"
            
        //taking datataskobj with completion handler
            dataTaskObj = URLSession.shared.dataTask(with: self.URLReq, completionHandler: {  (data, response, error) in
                // accssing data into json decoder method
                    let decoder = JSONDecoder()
                    do{
                convertedData = try  decoder.decode([MovieDetails].self, from: data!)
                    
                      //  print(convertedData)
                        
                        print(convertedData!.count)
                        

    
    DispatchQueue.main.sync {
        
        
        // passing convertedData in to for loop with industrywise
        var c=0
        for i in 0..<convertedData!.count
    {
            
            print("\(convertedData![i].industry)")
            
            // taking only tollywood posters from server
            
            if convertedData![i].industry == "Tollywood" {
            let tollywoodPosters = "https://services.brninfotech.com/tws/" +  convertedData![i].posters![0].replacingOccurrences(of: " ", with: "%20")
        
        
          //  print(tollywoodPosters)
                
        //taking tollywoodImages with UIButton
                
        self.tollywoodImages = UIButton(type: UIButton.ButtonType.custom)
        self.tollywoodImages.frame = CGRect(x: 20, y: 20+c*250, width: 200, height: 200)
            self.tollywoodImages.layer.cornerRadius = 20
            self.tollywoodImages.clipsToBounds = true
            self.tollywoodImages.imageEdgeInsets = .zero
        self.titleLbl = UILabel(frame: CGRect(x: 250, y: 20+c*250, width:200, height: 50))
                // giving add target tap action to posterButton
                self.tollywoodImages.addTarget(self, action: #selector(self.tabAction(tapaction:)), for: UIControl.Event.touchUpInside)
            self.titleLbl.textColor = .green
            print("\(convertedData![i].title!)")
            self.titleLbl.text = "\(convertedData![i].title!)"
            self.tollywoodscrollView.addSubview(self.titleLbl)
        self.tollywoodImages.contentMode = .scaleAspectFill
                //taking a tag
        self.tollywoodImages.tag = Int(i)
        self.tollywoodscrollView.addSubview(self.tollywoodImages)
            self.tollywoodscrollView.contentSize = CGSize(width: self.view.frame.width, height: self.tollywoodImages.frame.maxY)
        
            let imageURL = URL(string: tollywoodPosters)
            
            let data = try? Data(contentsOf: imageURL!)
            self.tollywoodImages.setImage(UIImage(data: data!), for: UIControl.State.normal)
                
                c += 1

                
       }
        
    }
        
                        
    }
            }catch{
            
            print(error)
            }
                
            })
                
            self.dataTaskObj.resume()
        
        
}

    // tab action for imageButton
  @objc func tabAction(tapaction:UIButton){
        
    let vc = storyboard?.instantiateViewController(identifier: "tvc1") as! DetailsViewController
    
    let tag = tapaction.tag
    
    //using push method for navigating tollywood viewController
    vc.details = convertedData![tag]
        navigationController?.pushViewController(vc, animated: true)
        
   
        
    }
}

