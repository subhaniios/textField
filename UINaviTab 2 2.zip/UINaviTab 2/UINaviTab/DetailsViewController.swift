//
//  TollywoodDetailsViewController.swift
//  UINaviTab
//
//  Created by subhanireddy on 08/02/21.
//

import UIKit
import AVKit
import AVFoundation


class DetailsViewController: UIViewController {
    var details:MovieDetails!
    var tittleLabel:UILabel!
    var actrosLabel:UILabel!
    var industryLabel:UILabel!
    var directorLabel:UILabel!
    var storyLabel:UILabel!
    var imageBtn:UIButton!
    var tollywoodaActorsLabel:UILabel!
    var tOllywoodmovieSongsArray:[String] = []
    var songsLabel:UILabel!
    var songsBtn:UIButton!
    var segmentControl:UISegmentedControl!
    var trailerArray:[String] = []
    var trailerLabel:UILabel!
    var scrollView:UIScrollView!
    var actorsArray:[String] = []
    var movieSongsArray:[String] = []
    var songsView:UIView!
    var trailerView:UIView!
    var trailerBtn:UIButton!
    var AVPVC:AVPlayerViewController!
    override func viewDidLoad() {
        self.scrollView = UIScrollView()
        self.scrollView.frame = CGRect(x: 0, y: 420, width: 415, height: 2000)
        self.scrollView.contentSize = CGSize(width: 415, height: 3000)
        self.scrollView.backgroundColor = UIColor.systemGray
        self.view.addSubview(self.scrollView)

    
        self.songsView = UIView(frame: CGRect(x: 0, y: 425, width: 415, height: 150))
        self.view.addSubview(self.songsView)

        self.trailerView = UIView(frame: CGRect(x: 0, y: 425, width: 415, height: 150))
        self.view.addSubview(self.trailerView)

       

        createUI()

        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    
    func createUI(){
    
        imageBtn = UIButton(type: UIButton.ButtonType.custom)
        imageBtn.frame = CGRect(x: 30, y: 100, width: 300, height: 300)
        imageBtn.layer.cornerRadius = 20
        imageBtn.clipsToBounds = true
        view.addSubview(imageBtn)
        imageBtn.contentMode = .scaleAspectFill
        
        
        let temp = "https://services.brninfotech.com/tws/" +  self.details.posters![0].replacingOccurrences(of: " ", with: "%20")


       var imageURL = URL(string: temp)

        let data = try? Data(contentsOf: imageURL!)


        imageBtn.setImage(UIImage(data: data!), for: UIControl.State.normal)

                
        let  moviesinfo = ["MovieDetails","Songs","Trailer"]
                       segmentControl = UISegmentedControl(items: moviesinfo)
                       segmentControl.backgroundColor = .gray
                       segmentControl.apportionsSegmentWidthsByContent = true
                       segmentControl.layer.cornerRadius = 15
                       segmentControl.layer.borderWidth = 2
                       segmentControl.layer.borderColor = UIColor.white.cgColor
                       segmentControl.tintColor = UIColor.black
                       segmentControl.layer.masksToBounds = true
                       segmentControl.frame = CGRect(x: 0, y: 380, width: 370, height: 40)
                       segmentControl.addTarget(self, action: #selector(segAction), for: UIControl.Event.valueChanged)
                       view.addSubview(segmentControl)
    }
    
    @objc func segAction(){
    
        DispatchQueue.main.async {
            
            if self.segmentControl.selectedSegmentIndex == 0 {
                self.songsView.removeFromSuperview()
                self.trailerView.removeFromSuperview()
                
                self.scrollView = UIScrollView()
                self.scrollView.frame = CGRect(x: 0, y: 420, width: 415, height: 2000)
                self.scrollView.contentSize = CGSize(width: 415, height: 3000)
                self.scrollView.backgroundColor = UIColor.systemGray
                          
                self.view.addSubview(self.scrollView)
            
            
               self.tittleLabel = UILabel()
           
               self.tittleLabel.frame = CGRect(x: 50, y: 40, width: 300, height:40)
               self.tittleLabel.text = "Tittle:-\(self.details!.title!)"
               self.tittleLabel.backgroundColor = .systemGreen
                self.tittleLabel.clipsToBounds = true
                self.tittleLabel.shadowColor = .cyan
                self.tittleLabel.textColor = .white
               self.tittleLabel.layer.masksToBounds = true
               
               self.tittleLabel.numberOfLines = 0
               self.tittleLabel.layer.cornerRadius = 5
               self.tittleLabel.textAlignment = .natural
               self.scrollView.addSubview(self.tittleLabel)
            
            
                if self.details.industry != nil {
                self.industryLabel = UILabel()
                self.industryLabel.frame = CGRect(x: 50, y:80 , width: 300, height:40)
                self.industryLabel.text = " Industry:-\(self.details!.industry!)"
                self.industryLabel.backgroundColor = .clear
                self.industryLabel.clipsToBounds = true
                self.industryLabel.shadowColor = .cyan
                self.industryLabel.textColor = .white
               self.industryLabel.backgroundColor = .clear
               self.industryLabel.textColor = .white
          
           
        self.scrollView.addSubview(self.industryLabel)
        }else{
            
            self.industryLabel.text = "Industry Not Avilable"
            
        }
            
            self.actorsArray = self.details.actors!
            var z = "Actors:-"
            for i in 0..<self.actorsArray.count{
                
            
            self.actrosLabel = UILabel()
               self.actrosLabel.frame = CGRect(x: 50, y: 150+i*20, width: 350, height:50)
                self.actrosLabel.text =  "\(z)\(self.actorsArray[i])"
                self.tittleLabel.backgroundColor = .systemBlue
                 self.tittleLabel.clipsToBounds = true
                 self.tittleLabel.shadowColor = .cyan
                 self.tittleLabel.textColor = .white
               self.actrosLabel.textColor = .white
               self.actrosLabel.layer.masksToBounds = true
               self.actrosLabel.numberOfLines = 0
               self.actrosLabel.layer.cornerRadius = 5
               self.actrosLabel.textAlignment = .natural
                if i == 0 {
                  z = ""
                }
            self.scrollView.addSubview(self.actrosLabel)
            
            }
           
               self.directorLabel = UILabel()
               self.directorLabel.frame = CGRect(x: 50, y: 250, width: 300, height:40)
               self.directorLabel.text = " Director:-\( self.details!.director!)"
               self.directorLabel.backgroundColor = .clear
               self.directorLabel.textColor = .white
               self.directorLabel.layer.masksToBounds = true
               
               self.directorLabel.numberOfLines = 0
               self.directorLabel.layer.cornerRadius = 5
               self.directorLabel.textAlignment = .natural
               self.scrollView.addSubview(self.directorLabel)
        
        
            
           self.storyLabel = UILabel()
           self.storyLabel.frame = CGRect(x: 50, y: 300, width: 300, height:500)
                self.storyLabel.backgroundColor = .clear
            if self.details.story != nil{
                self.storyLabel.text = "Story:-\(self.details!.story!)"
            }else
            {
                self.storyLabel.text = "Story Not Avilable"
            }
                self.storyLabel.numberOfLines = 0

           //self.storyLabel.backgroundColor = .clear
           self.storyLabel.textColor = .white
           self.storyLabel.sizeToFit()
           
        self.scrollView.addSubview(self.storyLabel)
        }
            if self.segmentControl.selectedSegmentIndex == 1{
                self.scrollView.removeFromSuperview()
                self.trailerView.removeFromSuperview()
                self.songsView = UIView(frame: CGRect(x: 0, y: 425, width: 415, height: 150))
                self.view.addSubview(self.songsView)
                
            let songsArr = self.details!.songs!
           // print(songsArr)
            self.movieSongsArray.removeAll()
            if (self.details!.songs != [])
            {
                for b in 0..<songsArr.count
                {
                    let temp1 = songsArr[b]
                    let temp2 = temp1.split(separator: "/")
                    let temp3 = temp2[3]
                    let temp4 = temp3.replacingOccurrences(of: ".mp3", with: "")
                 //   print(temp4)
                    self.songsLabel = UILabel()
                    self.songsLabel.frame = CGRect(x: 50, y: 10+(40*b), width:400, height: 50)
                    self.songsLabel.backgroundColor = .clear
                    self.songsLabel.textColor = .systemRed
                    self.songsLabel.layer.masksToBounds = true
                    self.songsLabel.font = .systemFont(ofSize: 22)
                    self.songsLabel.text = "\(temp4)"
                    self.songsLabel.clipsToBounds = true
                    self.songsLabel.layer.shadowOpacity = 20
                    self.songsLabel.numberOfLines = 0
                    self.songsLabel.layer.cornerRadius = 5
                    self.songsLabel.textAlignment = .natural
                    self.scrollView.contentSize.height = self.songsLabel.frame.maxY + 75
                    self.scrollView.contentSize.width = self.songsLabel.frame.maxX + 50
                    self.songsView.addSubview(self.songsLabel)
                    //self.songsLabel.sizeToFit()
                    
                    self.songsBtn = UIButton(type: UIButton.ButtonType.custom)
                    self.songsBtn.frame = CGRect(x: 4, y: 4+(40*b), width: 45, height: 40)
                   // self.songsBtn.setImage(UIImage(named: "playing"), for: UIControl.State.normal)
                    let temp = "https://services.brninfotech.com/tws/" +  self.details.posters![0].replacingOccurrences(of: " ", with: "%20")


                   var imageURL = URL(string: temp)

                    let data = try? Data(contentsOf: imageURL!)
                    self.songsBtn.setImage(UIImage(data: data!), for: UIControl.State.normal)
                    
                    self.songsBtn.tag = Int(b)
                    self.songsBtn.addTarget(self, action: #selector(self.songsPlayFunction(sender:)), for: UIControl.Event.touchUpInside)
                    self.movieSongsArray.append(temp1.replacingOccurrences(of: " ", with: "%20"))
                    self.songsView.addSubview(self.songsBtn)
                }
            }else
            {
                self.songsLabel = UILabel()
                self.songsLabel.frame = CGRect(x: 0, y: 10, width: 300, height: 50)
                self.songsLabel.textColor = .white
                self.songsLabel.backgroundColor = .clear
                self.songsLabel.font = .systemFont(ofSize: 23)
                self.songsLabel.textAlignment = .center
                self.songsLabel.text = "No Songs Available "
                self.scrollView.addSubview(self.songsLabel)
                self.songsLabel.sizeToFit()
                
            
            }
                
                
        }
            
            if self.segmentControl.selectedSegmentIndex == 2{
                
                self.scrollView.removeFromSuperview()
                self.songsView.removeFromSuperview()
                
                self.trailerView = UIView(frame: CGRect(x: 0, y: 425, width: 415, height: 150))
                self.view.addSubview(self.trailerView)
                
                self.trailerArray.removeAll()
                self.trailerArray = self.details!.trailers!
                for c in 0..<self.trailerArray.count
                {
                    let temp1 = self.trailerArray[c]
                    let temp2 = temp1.split(separator: "/")
                    let temp3 = temp2[2]
                    let temp4 = temp3.replacingOccurrences(of: ".mp4", with: "")
                    print(temp4)
                    self.trailerLabel = UILabel()
                    self.trailerLabel.frame = CGRect(x: 50, y: 10+(80*c), width:400, height: 80)
                    self.trailerLabel.backgroundColor = .clear
                    self.trailerLabel.textColor = .systemGreen
                    self.trailerLabel.font = .systemFont(ofSize: 20)
                    self.trailerLabel.text = "\(temp4)"
                    self.trailerView.addSubview(self.trailerLabel)
                    self.trailerLabel.sizeToFit()
                    
                    self.trailerBtn = UIButton(type: UIButton.ButtonType.custom)
                    self.trailerBtn.frame = CGRect(x: 4, y: 4+(40*c), width: 40, height: 40)
                  //  self.trailerBtn.setImage(UIImage(named: "playing"), for: UIControl.State.normal)
                    let temp = "https://services.brninfotech.com/tws/" +  self.details.posters![0].replacingOccurrences(of: " ", with: "%20")
                     var imageURL = URL(string: temp)

                    let data = try? Data(contentsOf: imageURL!)
                    self.trailerBtn.setImage(UIImage(data: data!), for: UIControl.State.normal)
                    self.trailerBtn.tag = Int(c)
                    self.trailerBtn.addTarget(self, action: #selector(self.videoPlayFunction(sender:)), for: UIControl.Event.touchUpInside)
                    self.trailerView.addSubview(self.trailerBtn)
                }
            }
        }
           
        
        }
        
    @objc func songsPlayFunction(sender:UIButton)
    {
        let tag = sender.tag
        let urlPath = URL(string: "https://services.brninfotech.com/tws/\(self.movieSongsArray[tag].replacingOccurrences(of: "", with: "%20"))")
     //   print(urlPath)
        
        self.AVPVC = AVPlayerViewController()
        self.AVPVC.player = AVPlayer(url:urlPath!)
        self.AVPVC.modalPresentationStyle = .currentContext
        self.AVPVC.allowsPictureInPicturePlayback = true
        present(self.AVPVC, animated: true)
        {
            
            self.AVPVC.player?.play()
        }
    }
    
    
    @objc func videoPlayFunction(sender:UIButton)
    {
        let tag = sender.tag
        let urlPath = URL(string: "https://services.brninfotech.com/tws/\(self.trailerArray[tag].replacingOccurrences(of: " ", with: "%20"))")
        
        self.AVPVC = AVPlayerViewController()
        self.AVPVC.player = AVPlayer(url: urlPath!)
       
        present(self.AVPVC, animated: true)
        {
            
            self.AVPVC.player?.play()
        }
    }
    


}
