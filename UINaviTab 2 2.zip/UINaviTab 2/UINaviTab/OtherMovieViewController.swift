//
//  OtherMovieViewController.swift
//  UINaviTab
//
//  Created by subhanireddy on 08/02/21.
//

import UIKit

class OtherMovieViewController: UIViewController {
    var othervc:ViewController!
    var otherwoodMoviePosters:UIButton!
    var otherwoodMovieTittleLabel:UILabel!
    var scrollview3:UIScrollView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollview3  = UIScrollView(frame: CGRect(x: 20, y: 20, width: 410, height: 900))
        view.addSubview(scrollview3)
        otherwoodMovies()

        // Do any additional setup after loading the view.
    }
    
    func otherwoodMovies(){
        var c = 0

       
        for k in 0..<convertedData!.count
    {
            var otherwoodPosters = "https://services.brninfotech.com/tws/" +  convertedData![k].posters![0].replacingOccurrences(of: " ", with: "%20")
        
            if convertedData![k].industry == "Sandalwood" || convertedData![k].industry == "Hollywood"   {

                
            print(otherwoodPosters)
                self.otherwoodMoviePosters = UIButton(type: UIButton.ButtonType.custom)
                self.otherwoodMoviePosters.frame = CGRect(x: 50, y: 20+c*250, width: 200, height: 200)
                self.otherwoodMoviePosters.layer.cornerRadius = 20
                self.otherwoodMoviePosters.clipsToBounds = true
                self.otherwoodMoviePosters.addTarget(self, action: #selector(tabAction(tapaction:)), for: UIControl.Event.touchUpInside)
                self.otherwoodMoviePosters.contentMode = .scaleAspectFill
                self.otherwoodMovieTittleLabel = UILabel(frame: CGRect(x: 250, y: 20+c*250, width: 150, height: 40))
                self.otherwoodMovieTittleLabel.textColor = .systemGreen
                print("\(convertedData![k].title!)")
                self.otherwoodMovieTittleLabel.text = "\(convertedData![k].title!)"
                self.scrollview3.addSubview(otherwoodMovieTittleLabel)
                self.otherwoodMoviePosters.tag = Int(k)
                scrollview3.addSubview(self.otherwoodMoviePosters)
                self.scrollview3.contentSize = CGSize(width: view.frame.width, height: otherwoodMoviePosters.frame.maxY)
                let bimagURL = URL(string: otherwoodPosters)
            
            let data = try? Data(contentsOf: bimagURL!)
                self.otherwoodMoviePosters.setImage(UIImage(data: data!), for: UIControl.State.normal)
                c += 1
       }
    }
}
    
    @objc func tabAction(tapaction:UIButton){
  
      let vc = storyboard?.instantiateViewController(identifier: "tvc1") as! DetailsViewController
  
      let tag = tapaction.tag
  
      //using push method for navigating tollywood viewController
      vc.details = convertedData![tag]
          navigationController?.pushViewController(vc, animated: true)
  }

}
