//
//  kollywoodViewController.swift
//  UINaviTab
//
//  Created by subhanireddy on 06/02/21.
//

import UIKit

class kollywoodViewController: UIViewController {
   
    var kollyvc:ViewController!
    var kollywoodMoviePosters:UIButton!
    var kollywoodMovieTittleLabel:UILabel!
    var scrollview3:UIScrollView!

    override func viewDidLoad() {
        super.viewDidLoad()
        scrollview3  = UIScrollView(frame: CGRect(x: 20, y: 20, width: 410, height: 900))
        view.addSubview(scrollview3)
        kollywoodMovies()

        // Do any additional setup after loading the view.
    }
    
    
    
    func kollywoodMovies(){
        var c = 0

       
        for k in 0..<convertedData!.count
    {
            var kollywoodPosters = "https://services.brninfotech.com/tws/" +  convertedData![k].posters![0].replacingOccurrences(of: " ", with: "%20")
        
            if convertedData![k].industry == "Kollywood"  {

                
            print(kollywoodPosters)
                self.kollywoodMoviePosters = UIButton(type: UIButton.ButtonType.custom)
                self.kollywoodMoviePosters.frame = CGRect(x: 50, y: 20+c*250, width: 200, height: 200)
                self.kollywoodMoviePosters.layer.cornerRadius = 20
                self.kollywoodMoviePosters.clipsToBounds = true
                self.kollywoodMoviePosters.addTarget(self, action: #selector(tabAction(tapaction:)), for: UIControl.Event.touchUpInside)
                self.kollywoodMoviePosters.contentMode = .scaleAspectFill
                self.kollywoodMovieTittleLabel = UILabel(frame: CGRect(x: 250, y: 20+c*250, width: 150, height: 40))
                self.kollywoodMovieTittleLabel.textColor = .systemGreen
                print("\(convertedData![k].title!)")
                self.kollywoodMovieTittleLabel.text = "\(convertedData![k].title!)"
                self.scrollview3.addSubview(kollywoodMovieTittleLabel)
                self.kollywoodMoviePosters.tag = Int(k)
                scrollview3.addSubview(self.kollywoodMoviePosters)
               
                let bimagURL = URL(string: kollywoodPosters)
            
            let data = try? Data(contentsOf: bimagURL!)
                self.kollywoodMoviePosters.setImage(UIImage(data: data!), for: UIControl.State.normal)
                 c += 1
       }
    }
        
}
    
      @objc func tabAction(tapaction:UIButton){
    
        let vc = storyboard?.instantiateViewController(identifier: "tvc1") as! DetailsViewController
    
        let tag = tapaction.tag
    
        //using push method for navigating tollywood viewController
        vc.details = convertedData![tag]
            navigationController?.pushViewController(vc, animated: true)
    }



}
