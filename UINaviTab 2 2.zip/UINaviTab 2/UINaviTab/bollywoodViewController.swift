//
//  bollywoodViewController.swift
//  UINaviTab
//
//  Created by subhanireddy on 07/02/21.
//

import UIKit

class bollywoodViewController: UIViewController {
    var mainvc:ViewController!
    var detials : MovieDetails!
    var bollywoodMoviePosters:UIButton!
    var bollywoodMovieTittleLabel:UILabel!
    var scrollview2:UIScrollView!

    override func viewDidLoad() {
        
        scrollview2  = UIScrollView(frame: CGRect(x: 20, y: 20, width: 410, height: 900))
        view.addSubview(scrollview2)
        bollywoodMovies()
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    func bollywoodMovies(){
        
        
        var c = 0

        for k in 0..<convertedData!.count
    {
            var bollywoodPosters = "https://services.brninfotech.com/tws/" +  convertedData![k].posters![0].replacingOccurrences(of: " ", with: "%20")
        
            if convertedData![k].industry == "Bollywood"  {

                
            print(bollywoodPosters)
                self.bollywoodMoviePosters = UIButton(type: UIButton.ButtonType.custom)
                self.bollywoodMoviePosters.frame = CGRect(x: 50, y: 80+c*250, width: 200, height: 200)
                self.bollywoodMoviePosters.layer.cornerRadius = 20
                self.bollywoodMoviePosters.clipsToBounds = true
                self.bollywoodMoviePosters.addTarget(self, action: #selector(tabAction(tapaction:)), for: UIControl.Event.touchUpInside)
                self.bollywoodMoviePosters.contentMode = .scaleAspectFill
                self.bollywoodMovieTittleLabel = UILabel(frame: CGRect(x: 250, y: 80+c*250, width: 150, height: 40))
                self.bollywoodMovieTittleLabel.textColor = .systemGreen
                print("\(convertedData![k].title!)")
                self.bollywoodMovieTittleLabel.text = "\(convertedData![k].title!)"
                self.view.addSubview(bollywoodMovieTittleLabel)
                self.bollywoodMoviePosters.tag = Int(k)
                self.view.addSubview(self.bollywoodMoviePosters)
               self.scrollview2.contentSize = CGSize(width: view.frame.width, height: bollywoodMoviePosters.frame.maxY)
                let bimagURL = URL(string: bollywoodPosters)
            
            let data = try? Data(contentsOf: bimagURL!)
                self.bollywoodMoviePosters.setImage(UIImage(data: data!), for: UIControl.State.normal)
                c += 1
       }
    }
        
}
    @objc func tabAction(tapaction:UIButton){
  
      let vc = storyboard?.instantiateViewController(identifier: "tvc1") as! DetailsViewController
  
      let tag = tapaction.tag
  
      //using push method for navigating tollywood viewController
      vc.details = convertedData![tag]
          navigationController?.pushViewController(vc, animated: true)
  }

}
